import 'package:get/get.dart';

class UserModel {
  final String userId;

  final String email;
  final String fullName;

  final DateTime createdAt;

  final String password;

  UserModel({
    required this.userId,
    required this.email,
    required this.fullName,
    required this.createdAt,
    required this.password,
  });

  Map<String, dynamic> toMap() {
    return {
      'userId': userId,
      'email': email,
      'fullName': fullName,
      'createdAt': createdAt.millisecondsSinceEpoch,
      'password': password,
    };
  }

  factory UserModel.fromMap(Map<String, dynamic> map) {
    return UserModel(
        userId: map['userId'] ?? '',
        email: map['email'] ?? '',
        fullName: map['fullName'] ?? '',
        createdAt: DateTime.fromMillisecondsSinceEpoch(map['createdAt']),
        password: map['password'] ?? '');
  }

  static UserModel? loggedInUser;
  static String defaultProfilePicture =
      'https://firebasestorage.googleapis.com/v0/b/kwlei-f8fcc.appspot.com/o/default%20profile%20pic.png?alt=media&token=a8f6adf7-6ee2-4dd0-934c-8bd7b0242341';
}
