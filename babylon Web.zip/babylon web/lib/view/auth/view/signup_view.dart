import 'package:babylon/components/custom_button_widget.dart';
import 'package:babylon/components/custom_text_form_field.dart';
import 'package:babylon/utils/app_text.dart';
import 'package:babylon/utils/app_theme.dart';
import 'package:babylon/utils/ui_gaps.dart';
import 'package:babylon/view/auth/controller/auth_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';

class SignupView extends StatelessWidget {
  const SignupView({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.find<AuthController>();
    return Obx(() => ModalProgressHUD(
        inAsyncCall: controller.isLoading.value,
        child: SafeArea(
            child: Scaffold(
                body: Stack(children: [
          Container(
            height: Get.height / 2,
            width: Get.width,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                  colors: [AppTheme.lightPurpleColor, AppTheme.primaryColor]),
              borderRadius: BorderRadius.vertical(
                bottom: Radius.elliptical(Get.width, 50.0),
              ),
            ),
          ),
          Center(
            child: Container(
                padding: EdgeInsets.all(15),
                width: Get.width * 0.9,
                decoration: BoxDecoration(
                  color: AppTheme.whiteColor,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.5),
                      spreadRadius: 5,
                      blurRadius: 7,
                      offset: Offset(0, 3), // changes position of shadow
                    ),
                  ],
                ),
                child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      AppText(
                          text: "Sign up",
                          fontSize: 20,
                          color: AppTheme.textBlackColor,
                          fontWeight: FontWeight.bold),
                      verticalSpace(10),
                      Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            AppText(
                                text: "Already have an account?",
                                fontSize: 14,
                                color: Colors.black),
                            horizontalSpace(5),
                            InkWell(
                              onTap: () {
                                Get.back();
                              },
                              child: AppText(
                                  text: "Signin here",
                                  fontSize: 14,
                                  color: AppTheme.primaryColor,
                                  fontWeight: FontWeight.bold),
                            ),
                          ]),
                      verticalSpace(10),
                      verticalSpace(20),
                      Form(
                        key: controller.signUpformKey,
                        child: Column(
                          children: [
                            CustomTextFormField(
                              fieldLabel: 'Name',
                              controller: controller.tecNameS,
                              hintText: "John",
                              focusNode: controller.fnNameS,
                              validator: (value) {
                                if (value!.isEmpty) {
                                  return 'Please enter your Name';
                                }
                                return null;
                              },
                            ),
                            verticalSpace(10),
                            CustomTextFormField(
                              fieldLabel: 'Email',
                              validator: (value) {
                                if (value!.isEmpty) {
                                  return 'Please enter your email';
                                } else if (!RegExp(
                                        r'^[\w-]+(\.[\w-]+)*@[\w-]+(\.[\w-]+)+$')
                                    .hasMatch(value)) {
                                  return 'Please enter a valid email address';
                                }
                                return null;
                              },
                              controller: controller.tecEmailS,
                              hintText: "test@test.com",
                              focusNode: controller.fnEmailS,
                            ),
                            verticalSpace(10),
                            CustomTextFormField(
                              fieldLabel: 'Password',
                              validator: (value) {
                                if (value != null) {
                                  if (value.isEmpty) {
                                    return 'Please enter your password';
                                  } else if (value.length < 6) {
                                    return 'Password must be at least 6 characters long';
                                  }
                                }
                                return null;
                              },
                              controller: controller.tecPasswordS,
                              obscureText: !controller.isObscureS1.value,
                              suffix: InkWell(
                                onTap: () {
                                  controller.isObscureS1.value =
                                      !controller.isObscureS1.value;
                                },
                                child: Icon(controller.isObscureS1.value
                                    ? Icons.visibility
                                    : Icons.visibility_off),
                              ),
                              hintText: "******",
                              focusNode: controller.fnPasswordS,
                            ),
                            verticalSpace(10),
                            CustomTextFormField(
                              fieldLabel: 'Confirm Password',
                              controller: controller.tecCPasswordS,
                              obscureText: !controller.isObscureS2.value,
                              suffix: InkWell(
                                onTap: () {
                                  controller.isObscureS2.value =
                                      !controller.isObscureS2.value;
                                },
                                child: Icon(controller.isObscureS2.value
                                    ? Icons.visibility
                                    : Icons.visibility_off),
                              ),
                              hintText: "******",
                              validator: (value) {
                                if (value != null) {
                                  if (value.isEmpty) {
                                    return 'Please confirm your password';
                                  } else if (value.length < 6) {
                                    return 'Password must be at least 6 characters long';
                                  } else if (value !=
                                      controller.tecPasswordS.text) {
                                    return 'Passwords do not match';
                                  }
                                }
                                return null;
                              },
                              focusNode: controller.fnCPasswordS,
                            ),
                          ],
                        ),
                      ),
                      verticalSpace(40),
                      CustomButtonWidget(
                        btnLabel: 'Sign Up',
                        onTap: () {
                          if (controller.signUpformKey.currentState!
                              .validate()) {
                            controller.signUp();
                          }
                        },
                      ),
                      verticalSpace(10)
                    ])),
          )
        ])))));
  }
}
