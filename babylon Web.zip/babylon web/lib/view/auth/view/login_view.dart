import 'package:babylon/components/custom_button_widget.dart';
import 'package:babylon/components/custom_text_form_field.dart';
import 'package:babylon/utils/app_routes.dart';
import 'package:babylon/utils/app_text.dart';
import 'package:babylon/utils/app_theme.dart';
import 'package:babylon/utils/ui_gaps.dart';
import 'package:babylon/view/auth/controller/auth_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';

class LoginView extends StatelessWidget {
  const LoginView({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.put(AuthController());
    return Obx(() => ModalProgressHUD(
        inAsyncCall: controller.isLoading.value,
        child: SafeArea(
            child: Scaffold(
                body: Stack(children: [
          Container(
            height: Get.height / 2,
            width: Get.width,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                  colors: [AppTheme.lightPurpleColor, AppTheme.primaryColor]),
              borderRadius: BorderRadius.vertical(
                bottom: Radius.elliptical(Get.width, 50.0),
              ),
            ),
          ),
          Center(
            child: Container(
                padding: EdgeInsets.all(15),
                width: Get.width * 0.9,
                decoration: BoxDecoration(
                  color: AppTheme.whiteColor,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.5),
                      spreadRadius: 5,
                      blurRadius: 7,
                      offset: Offset(0, 3), // changes position of shadow
                    ),
                  ],
                ),
                child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      AppText(
                          text: "Sign in",
                          fontSize: 20,
                          color: AppTheme.textBlackColor,
                          fontWeight: FontWeight.bold),
                      verticalSpace(10),
                      Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            AppText(
                                text: "Don't have an account?",
                                fontSize: 14,
                                color: Colors.black),
                            horizontalSpace(5),
                            InkWell(
                              onTap: () {
                                Get.toNamed(AppRoutes.signUpScreen);
                              },
                              child: AppText(
                                  text: "SignUp here",
                                  fontSize: 14,
                                  color: AppTheme.primaryColor,
                                  fontWeight: FontWeight.bold),
                            ),
                          ]),
                      verticalSpace(10),
                      verticalSpace(20),
                      Form(
                        key: controller.loginformKey,
                        child: Column(
                          children: [
                            CustomTextFormField(
                              fieldLabel: 'Email',
                              controller: controller.tecEmailL,
                              hintText: "test@test.com",
                              validator: (value) {
                                if (value!.isEmpty) {
                                  return 'Please enter your email';
                                } else if (!RegExp(
                                        r'^[\w-]+(\.[\w-]+)*@[\w-]+(\.[\w-]+)+$')
                                    .hasMatch(value)) {
                                  return 'Please enter a valid email address';
                                }
                                return null;
                              },
                              focusNode: controller.fnEmailL,
                            ),
                            verticalSpace(10),
                            CustomTextFormField(
                              fieldLabel: 'Password',
                              obscureText: !controller.isObscureL.value,
                              controller: controller.tecPasswordL,
                              hintText: "******",
                              suffix: InkWell(
                                onTap: () {
                                  controller.isObscureL.value =
                                      !controller.isObscureL.value;
                                },
                                child: Icon(controller.isObscureL.value
                                    ? Icons.visibility
                                    : Icons.visibility_off),
                              ),
                              validator: (value) {
                                if (value != null) {
                                  if (value.isEmpty) {
                                    return 'Please enter your password';
                                  } else if (value.length < 6) {
                                    return 'Password must be at least 6 characters long';
                                  }
                                }
                                return null;
                              },
                              focusNode: controller.fnPasswordL,
                            ),
                          ],
                        ),
                      ),
                      verticalSpace(40),
                      CustomButtonWidget(
                        btnLabel: 'Sign in',
                        onTap: () {
                          if (controller.loginformKey.currentState!
                              .validate()) {
                            controller.logIn();
                          }
                        },
                      ),
                      verticalSpace(10)
                    ])),
          )
        ])))));
  }
}
