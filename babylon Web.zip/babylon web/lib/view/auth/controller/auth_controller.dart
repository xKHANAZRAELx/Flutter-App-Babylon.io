import 'package:babylon/models/user_model.dart';
import 'package:babylon/utils/app_routes.dart';
import 'package:babylon/utils/app_theme.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class AuthController extends GetxController {
  GlobalKey<FormState> signUpformKey = GlobalKey<FormState>();
  GlobalKey<FormState> loginformKey = GlobalKey<FormState>();
  final tecNameS = TextEditingController();

  final tecEmailS = TextEditingController();
  final tecEmailL = TextEditingController();
  final tecPasswordS = TextEditingController();
  final tecPasswordL = TextEditingController();
  final tecCPasswordS = TextEditingController();

  final fnNameS = FocusNode();
  final fnEmailS = FocusNode();
  final fnEmailL = FocusNode();
  final fnPasswordS = FocusNode();
  final fnPasswordL = FocusNode();
  final fnCPasswordS = FocusNode();

  RxBool isObscureL = false.obs;
  RxBool isObscureS1 = false.obs;
  RxBool isObscureS2 = false.obs;

  RxBool isLoading = false.obs;

  Future<void> signUp() async {
    UserCredential? userCredentials;
    try {
      isLoading.value = true;
      userCredentials = await FirebaseAuth.instance
          .createUserWithEmailAndPassword(
              email: tecEmailS.text, password: tecPasswordS.text.trim());
      print('Instance created');
      print('Email: ${tecEmailS.text}');
      print('Password: ${tecPasswordS.text}');

      if (userCredentials != null) {
        String uid = userCredentials.user!.uid;

        print('User ID: $uid');
        UserModel newUser = UserModel(
          userId: uid,
          fullName: tecNameS.text,
          createdAt: DateTime.now(),
          email: tecEmailS.text,
          password: tecPasswordS.text,
        );

        await FirebaseFirestore.instance
            .collection('users')
            .doc(uid)
            .set(newUser.toMap());

        isLoading.value = false;

        Get.offAllNamed(AppRoutes.homeView);
      }
    } on FirebaseAuthException catch (e) {
      print('Error occurred while signing in: ${e.message}');
      isLoading.value = false;

      Get.snackbar('Error', e.message.toString(),
          backgroundColor: AppTheme.redColor, colorText: AppTheme.whiteColor);
    }
  }

  Future<void> logIn() async {
    try {
      isLoading.value = true;

      UserCredential? userCredential = await FirebaseAuth.instance
          .signInWithEmailAndPassword(
              email: tecEmailL.text, password: tecPasswordL.text);
      print(userCredential);
      if (userCredential.user != null) {
        final userId = userCredential.user!.uid;
        print(userId);
        DocumentSnapshot userSnapshot = await FirebaseFirestore.instance
            .collection('users')
            .doc(userId)
            .get();

        if (userSnapshot.exists) {
          isLoading.value = false;

          Get.offAllNamed(AppRoutes.homeView);
        } else {
          Get.snackbar('Error', 'User Not Found',
              backgroundColor: AppTheme.redColor,
              colorText: AppTheme.whiteColor);
          isLoading.value = false;
        }
      }
    } on FirebaseAuthException catch (e) {
      isLoading.value = false;

      switch (e.code) {
        case "invalid-email":
          Get.snackbar('Error', 'Invalid Email',
              backgroundColor: AppTheme.redColor,
              colorText: AppTheme.whiteColor);
          break;
        case "user-disabled":
          Get.snackbar('Error', 'User Disabled!',
              backgroundColor: AppTheme.redColor,
              colorText: AppTheme.whiteColor);
          break;
        case "user-not-found":
          Get.snackbar('Error', 'User Not Found',
              backgroundColor: AppTheme.redColor,
              colorText: AppTheme.whiteColor);
          break;
        case "invalid-credential":
          Get.snackbar('Error', 'Email or Password is incorrect',
              backgroundColor: AppTheme.redColor,
              colorText: AppTheme.whiteColor);
          break;
        default:
          print(e.code);

          print(e.message);
          Get.snackbar('Error', e.message.toString());
      }
    } catch (e) {
      isLoading.value = false;
      print('Error: ${e.toString()}');
    }
  }
}
