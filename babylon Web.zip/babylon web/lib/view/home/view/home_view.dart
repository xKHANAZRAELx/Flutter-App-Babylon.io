import 'package:babylon/components/custom_button_widget.dart';
import 'package:babylon/utils/app_text.dart';
import 'package:babylon/utils/app_theme.dart';
import 'package:babylon/utils/ui_gaps.dart';
import 'package:babylon/view/home/controller/home_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class HomeView extends StatelessWidget {
  const HomeView({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.put(HomeController());
    return Scaffold(
      backgroundColor: AppTheme.backgroundColor,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            children: [
              const Spacer(),
              Obx(() {
                final user = controller.loggedInUser.value;
                return AppText(
                  text: user != null
                      ? "Hey ${user.fullName ?? ''}!"
                      : "Hey there!", // Fallback text when user is null
                  color: AppTheme.primaryColor,
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                  textAlign: TextAlign.center,
                );
              }),
              AppText(
                text: "You're successfully logged in",
                color: AppTheme.textBlackColor,
                fontSize: 16,
                fontWeight: FontWeight.w500,
                textAlign: TextAlign.center,
              ),
              const Spacer(),
              Align(
                alignment: Alignment.bottomCenter,
                child: CustomButtonWidget(
                  btnLabel: 'Sign out',
                  onTap: () {
                    controller.signOut();
                  },
                ),
              ),
              verticalSpace(20),
            ],
          ),
        ),
      ),
    );
  }
}
