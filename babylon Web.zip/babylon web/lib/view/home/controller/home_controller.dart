import 'package:babylon/models/user_model.dart';
import 'package:babylon/utils/app_routes.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:get/get.dart';

class HomeController extends GetxController {
  final auth = FirebaseAuth.instance;

  Rx<UserModel?> loggedInUser = Rx<UserModel?>(null);
  Future<void> fetchUserData() async {
    try {
      String? userId = auth.currentUser?.uid;
      if (userId != null) {
        DocumentSnapshot<Map<String, dynamic>> snapshot =
            await FirebaseFirestore.instance
                .collection('users')
                .doc(userId)
                .get();
        if (snapshot.exists) {
          UserModel user = UserModel.fromMap(snapshot.data()!);
          loggedInUser.value = user;
          print('printing inside home===========${loggedInUser.value}');
        }
      }
    } catch (e) {
      print('Error fetching user data: $e');
    }
  }

  @override
  void onInit() {
    // TODO: implement onInit
    fetchUserData();
    super.onInit();
  }

  void signOut() async {
    await auth.signOut().then((val) {
      Get.offAllNamed(AppRoutes.loginView);
    });
  }
}
