import 'package:flutter/material.dart';

class AppTheme {
  static const primaryColor = Color(0xffff6b4c);
  static const lightGreenColor = Color(0xff73d69d);
  static const borderColor = Color(0xff797979);
  static const backgroundColor = Color(0xfffaf5f1);
  static const whiteColor = Color(0xffffffff);
  static const hintTextColor = Color(0xff999999);
  static const textBlackColor = Color(0xff333333);
  static const blackColor = Color(0xff000000);
  static const textfieldBorder = Color(0xffced4da);
  static const redSwitchColor = Color(0xffc00017);
  static const redColor = Color(0xffD2122E);
  static const buttonColor = Color(0xff263951);
  static const lightPurpleColor = Color(0xffb8c4e4);
}
