import 'package:babylon/view/auth/view/login_view.dart';
import 'package:babylon/view/auth/view/signup_view.dart';
import 'package:babylon/view/home/view/home_view.dart';
import 'package:get/get.dart';

class AppRoutes {
  static String signUpScreen = "/signUpScreen";

  static String loginView = "/loginView";
  static String homeView = "/homeView";

  static List<GetPage> routes = [
    GetPage(
        name: loginView, page: () => LoginView(), transition: Transition.fade),
    GetPage(
        name: signUpScreen,
        page: () => SignupView(),
        transition: Transition.fade),
    GetPage(
        name: homeView, page: () => HomeView(), transition: Transition.fade),
  ];
}
