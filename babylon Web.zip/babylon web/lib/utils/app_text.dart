import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppText extends StatelessWidget {
  final String text;
  final Color? color;
  final double? fontSize;
  final FontWeight? fontWeight;
  final TextAlign? textAlign;
  final int? maxLines;
  final double? letterSpacing;
  final TextOverflow? overflow;
  final TextDecoration? decoration;
  final TextStyle? style;
  final Color? decorationColor;

  const AppText({
    Key? key,
    required this.text,
    this.color,
    this.fontSize,
    this.fontWeight,
    this.style,
    this.letterSpacing,
    this.textAlign,
    this.maxLines,
    this.overflow,
    this.decorationColor,
    this.decoration,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      textAlign: textAlign ?? TextAlign.start,
      maxLines: maxLines,
      overflow: overflow ?? TextOverflow.ellipsis,
      style: style ??
          GoogleFonts.montserrat(
              color: color ?? Colors.white,
              fontSize: fontSize ?? 14.0,
              letterSpacing: letterSpacing,
              fontWeight: fontWeight ?? FontWeight.w400,
              decoration: decoration ?? TextDecoration.none,
              decorationColor: decorationColor),
    );
  }
}
