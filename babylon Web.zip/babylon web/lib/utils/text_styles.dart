import 'package:babylon/utils/app_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class TextStyles {
  static TextStyle labelTextStyle = GoogleFonts.montserrat(
    fontWeight: FontWeight.w400,
    fontSize: 14,
    color: AppTheme.textBlackColor,
  );
}
