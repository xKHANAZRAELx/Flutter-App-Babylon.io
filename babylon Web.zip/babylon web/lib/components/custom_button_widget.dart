import 'package:babylon/utils/app_theme.dart';
import 'package:babylon/utils/text_styles.dart';
import 'package:flutter/material.dart';

import 'package:get/get.dart';

//ignore: must_be_immutable
class CustomButtonWidget extends StatelessWidget {
  final VoidCallback? onTap;
  String btnLabel = "";

  final double borderRadius;
  final double height;
  final TextStyle? btnLabelStyle;
  final bool isGradientBg;
  final bool isWhiteBg;
  final Color bgColor;
  final Color? borderColor;
  final bool isBtnDisabled;
  CustomButtonWidget({
    required this.btnLabel,
    this.onTap,
    this.borderRadius = 8.0,
    this.height = 50.0,
    this.isWhiteBg = false,
    this.bgColor = AppTheme.buttonColor,
    this.isBtnDisabled = false,
    this.btnLabelStyle,
    this.isGradientBg = false,
    this.borderColor = AppTheme.primaryColor,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: Get.width,
      height: height,
      margin: EdgeInsets.only(
        left: 0,
        right: 0,
      ),
      decoration: BoxDecoration(
          shape: BoxShape.rectangle,
          color: isWhiteBg
              ? AppTheme.whiteColor
              : isGradientBg
                  ? null
                  : isBtnDisabled
                      ? AppTheme.whiteColor
                      : bgColor,
          // gradient: isGradientBg ? kPrimaryLinearGradient : null,
          borderRadius: BorderRadius.circular(borderRadius),
          border:
              Border.all(color: isWhiteBg ? borderColor! : Colors.transparent)),
      child: ElevatedButton(
        style: const ButtonStyle(
            elevation: WidgetStatePropertyAll(0),
            backgroundColor: WidgetStatePropertyAll(Colors.transparent)),
        onPressed: onTap,
        child: Text(
          btnLabel,
          style: btnLabelStyle ??
              TextStyles.labelTextStyle.copyWith(
                  fontWeight: FontWeight.w600,
                  fontSize: 16,
                  color: isWhiteBg
                      ? AppTheme.primaryColor
                      : isBtnDisabled
                          ? AppTheme.textBlackColor
                          : AppTheme.whiteColor),
        ),
      ),
    );
  }
}
