package com.babylon.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
